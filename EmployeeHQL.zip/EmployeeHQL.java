import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Id;



@Entity
@Table(name="emp1_Table")
public class EmployeeHQL {
	
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int employeeid;
private String employeename;
private float employeesalary;
public EmployeeHQL() {
	super();
}
public int getEmployeeid() {
	return employeeid;
}
public void setEmployeeid(int employeeid) {
	this.employeeid = employeeid;
}
public String getEmployeename() {
	return employeename;
}
public void setEmployeename(String employeename) {
	this.employeename = employeename;
}
public float getEmployeesalary() {
	return employeesalary;
}
public void setEmployeesalary(float employeesalary) {
	this.employeesalary = employeesalary;
}
@Override
public String toString() {
	return "EmployeeHQL [employeeid=" + employeeid + ", employeename=" + employeename + ", employeesalary="
			+ employeesalary + "]";
}
}

