import java.util.Scanner;

import org.hibernate.SessionFactory;

public class EmployeeHQLMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		SessionFactory sf=HibernateUtil.getSessionFact();
				
		while(true) {
		System.out.println("*********MAIN MENU**********");
		System.out.println("1. Add records");
		System.out.println("2. Get All Records");
		System.out.println("3. Get Record by Employee Id");
		System.out.println("4.Update Employee name");
		System.out.println("5. Delete Employee by Id");
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
		
		switch(ch) {
		
		case 1: HibernateOperations.addEmployee(sf);
		break;
		case 2: HibernateOperations.getAllRecords(sf);
		break;
		case 3: HibernateOperations.getEmployeebyId(sf);
		break;
		case 4: HibernateOperations.updateEmployeeName(sf);
		break;
		case 5: HibernateOperations.deleteEmployeebyId(sf);
		break;
		default: System.out.println("invalid input");
		break;
		}//switch
		
		System.out.println("Do you want to continue (y/n)");
		char option=sc.next().charAt(0);
		if(option=='n')
			break;
	} //while
        System.out.println("Program is terminated");
	}
}
