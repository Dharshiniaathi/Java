


import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class HibernateOperations {

	public static void addEmployee(SessionFactory sf) {
		System.out.println("Add Employee");
		//Session ss=sf.openSession();
		try(Session ss=sf.openSession()){  //try with resources java 7
		Transaction t=ss.beginTransaction();
		
		EmployeeHQL e1=new EmployeeHQL();
		e1.setEmployeename("Bharani");
		e1.setEmployeesalary(65432f);
        ss.save(e1);
        
        EmployeeHQL e2=new EmployeeHQL();
        e2.setEmployeename("Dharshini");
        e2.setEmployeesalary(65442f);
        ss.save(e2);
        
        EmployeeHQL e3=new EmployeeHQL();
        e3.setEmployeename("Sandhiya");
        e3.setEmployeesalary(65452f);
        ss.save(e3);
        t.commit();
	}
	}

	public static void getAllRecords(SessionFactory sf) {
		System.out.println("Get All Employee Records");
		try(Session ss=sf.openSession()){
			Transaction t=ss.beginTransaction();
			String sql="FROM EmployeeHQL";
			Query<EmployeeHQL> list=ss.createQuery(sql,EmployeeHQL.class); 
			List<EmployeeHQL> l=list.list();
			Iterator<EmployeeHQL> it=l.iterator();
			System.out.println("ID\tName\tSalary");
			
			while(it.hasNext()) {
			EmployeeHQL eob=it.next();	
			
				System.out.println(eob.getEmployeeid()+"\t"+eob.getEmployeename()+"\t"+eob.getEmployeesalary());
			}//while
		}//try	

		
	}

	public static void getEmployeebyId(SessionFactory sf) {
		System.out.println("Get Employee by using Id");
		try(Session session=sf.openSession()){
			//get employee
			String sel="FROM EmployeeHQL where employeeId=:id";
			Query<EmployeeHQL> q=session.createQuery(sel, EmployeeHQL.class);
			q.setParameter("id", 1); //position starts 0
			EmployeeHQL eob=q.uniqueResult(); //singleresult
			System.out.println(eob);
		}
	}

	public static void updateEmployeeName(SessionFactory sf) {
       System.out.println("Update Employee Name");
       
       System.out.println("Update Employee Name");
		try(Session session=sf.openSession()){
			
			Transaction tx=session.beginTransaction();
			Query q=session.createQuery("update EmployeeHQL set employeeName=:n where employeeId=:i");  
			q.setParameter("n","Udit Kumar");  
			q.setParameter("i",1);  
			  
			int status=q.executeUpdate();  
			if(status>1) {
			System.out.println(status +"Record updated");  
	      tx.commit();
			}
		}
	}
	
	public static void deleteEmployeebyId(SessionFactory sf) {
		System.out.println("Delete Employee by using Id ");
		
		try(Session session=sf.openSession()){
			
			Transaction tx=session.beginTransaction();
			Query q=session.createQuery("delete from EmployeeHQL where employeeId=2");  
			//specifying class name (Emp) not tablename  
			
			int status=q.executeUpdate();  
			if(status>1) {
			System.out.println(status +"Record deleted");  
			tx.commit();  

			}
		
	}

}
	
}
